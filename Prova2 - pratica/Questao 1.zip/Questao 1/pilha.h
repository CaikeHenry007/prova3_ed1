#define TAM_MAX 52

typedef struct _carta {
	int numero;
	char naipe[1];
} carta;

typedef struct _pilha {
    int vetor[TAM_MAX];
    int topo;
} pilha;

void inicializar();
int verificarVazia();
int verificarCheia();
void push(int dado);
void imprimir();
int pop();
