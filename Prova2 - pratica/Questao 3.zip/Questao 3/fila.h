#define TAM_MAX 10

typedef struct _Vagao {
	int codigo;
	float peso;
} Vagao;

typedef struct fila {
	Vagao vetor[TAM_MAX];
	int final;
} Fila;

void inicializar();
int verificarVazia();
int verificarCheia();
void inserir(Vagao novoVagao);
void imprimir();
Vagao remover();
