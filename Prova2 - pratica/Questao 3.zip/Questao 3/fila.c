#include <stdio.h>
#include "fila.h"

Fila f;

void inicializar(){
	f.final = -1;
}

int verificarVazia(){
	if(f.final == -1)
		return 1;
	else return 0;
}

int verificarCheia() {
	if(f.final == TAM_MAX - 1)
		return 1;
	else return 0;
}

void inserir(Vagao novoVagao){
	//verificar se a fila nao estah cheia
	if(!verificarCheia() && calcularPeso() <= 10000) {
		//atualiza o final da fila	
		f.final++;
		//insere o numero no vetor no final
		f.vetor[f.final] = novoVagao;
	} else {
		//informa o usuario que a fila estah cheia
		printf("\nNao eh possivel adicionar mais vagoes ao trem.");
	}
}

void imprimirVagao(Vagao v) {
	printf("\nVagao codigo: %d \tPeso: %f", v.codigo, v.peso);
}

void calcularPeso() {
	float pesoTotal;
	int i;
	  for(i = 0; i <= f.final; i++){
     	pesoTotal += f.final[i];
	}
	printf("\nO peso total do trem e: %f", pesoTotal);
}

void imprimir(){
	//verificar se a fila nao estah vazia
	if(!verificarVazia()) {
		int i;
		printf("\nOs vagoes no trem sao: ");
		//percorrer o vetor de 0 ateh f.final
		for(i = 0; i <= f.final; i++)
			//imprimir o elemento na posicao i
			imprimirVagao(f.vetor[i]);
			calcularPeso();
	} else {
		printf("\nO trem nao possui vagoes.");
	}
}

Vagao remover() {
	//verificar se a fila nao estah vazia
	if(!verificarVazia()) {
		Vagao aux;
		int i;
		//aux irah guardar o elemento do inicio da fila
		aux = f.vetor[0];
		//translada os elementos do inicio ao fim -1
		for(i = 0; i <= f.final -1; i++)
			//a posicao i receber o valor da posicao i+1
			f.vetor[i] = f.vetor[i+1];
		//atualizar o final da fila
		f.final--;
		return aux;
	} else {
		Vagao aux = {-1, -1};
		printf("O trem nao possui vagao a remover.");
		return aux;
	}
}
