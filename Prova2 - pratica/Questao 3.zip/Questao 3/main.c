#include <stdio.h>
#include "fila.h"

int main(int argc, char *argv[]) {
	Vagao vagao;
	int opcao;
	inicializar();

	do {
		//exibir o menu
		printf("\n    MENU");
		printf("\n1. Inicializar");
		printf("\n2. Inserir");
		printf("\n3. Remover");
		printf("\n4. Imprimir");
		printf("\n5. Sair");
		printf("\nDigite a opcao desejada: ");
		
		//ler a opcao desejada pelo usuario
		scanf("%d", &opcao);
		
		//processar a funcionalidade
		switch(opcao) {
			case 1:
				inicializar();
				break;
			case 2:
				printf("\nDigite o codigo do vagao:");
				scanf("%d", &vagao.codigo);
				printf("\nDigite o peso do vagao:");
				scanf("%f", &vagao.peso);
				inserir(vagao);
				break;
			case 3:
				vagao = remover();
				if(vagao.codigo != -1) {
					printf("\nCodigo do vagao removido: %d", vagao.codigo);
				}
				break;
			case 4:
				imprimir();
				break;
			case 5:
				printf("Encerrando o programa...");
				break;
			default:
				printf("\nOpcao invalida. Escolha um numero valido de opcao.");
		}
		
	} while(opcao != 5);
}
