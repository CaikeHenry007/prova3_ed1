#define TAM_MAX 5

typedef struct processo {
	int id;
	char nome[50];
	int tempo;
} Processo;

typedef struct _Lista {
    Processo vetor[TAM_MAX];
    int fim;
} Lista;

void inicializar();
int verificarVazia();
int verificarCheia();
void inserir(Processo novoProcesso, int posicao);
void imprimir();
Processo remover(int posicao);

