#include <stdio.h>
#include "lista.h"

int main(int argc, char *argv[]) {
	Processo temp;
	int opcao, posicao;
	inicializar();

	do {
		//exibir o menu
		printf("\n\n\nQUESTAO 02 - LISTA DE PROCESSOS");
		printf("\n    MENU");
		printf("\n1. Inicializar");
		printf("\n2. Inserir");
		printf("\n3. Remover");
		printf("\n4. Imprimir");
		printf("\n5. Inserir dados de processos para teste");
		printf("\n8. Sair");
		printf("\nDigite a opcao desejada: ");
		
		//ler a opcao desejada pelo usuario
		scanf("%d", &opcao);
		
		//processar a funcionalidade
		switch(opcao) {
			case 1:
				inicializar();
				break;
			case 2:
				printf("Digite o identificador: ");
				scanf("%d", &temp.id);
				printf("Digite o nome do programa: ");
				scanf("%s", temp.nome);
				printf("Digite o tempo: ");
				scanf("%d", &temp.tempo);
				printf("Digite a posicao: ");
				scanf("%d", &posicao);
				inserir(temp, posicao);
				break;
			case 3:
				printf("Digite a posicao: ");
				scanf("%d", &posicao);
				temp = remover(posicao);
				if (temp.id != -1)
					printf("\nProcesso removido: %s", temp.nome);
				break;
			case 4:
				imprimir();
				break;
			case 5: {
				Processo exemplo1 = {1, "teste1.exe", 5}, 
				exemplo2 = {2, "teste2.exe", 7},
				exemplo3 {3, "teste3.exe", 10};
				inicializar();
				inserir(exemplo1, 0);
				inserir(exemplo2, 1);
				inserir(exemplo3, 1);			
			}
			break;
			case 8:
				printf("Encerrando o programa...");
				break;
			default:
				printf("\nOpcao invalida. Escolha um numero valido de opcao.");
		}
		
	} while(opcao != 8);
}

